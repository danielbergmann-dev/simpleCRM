export const environment = {
  firebase: {
    projectId: 'simple-crm-e99bc',
    appId: '1:522331051274:web:51d0eed4be9564d356d6f3',
    storageBucket: 'simple-crm-e99bc.appspot.com',
    apiKey: 'AIzaSyCJlqibSlyAbBJw2nAmRVG0EapzIkzGeT8',
    authDomain: 'simple-crm-e99bc.firebaseapp.com',
    messagingSenderId: '522331051274',
    databaseURL: 'https://simple-crm-e99bc-default-rtdb.firebaseio.com/',
  },
};